export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/30 py-12">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
                <div className="grid h-5 w-5 grid-cols-2 grid-rows-2 gap-[2px]">
                  <div className="bg-red-500 rounded-sm" />
                  <div className="bg-blue-500 rounded-sm" />
                  <div className="bg-green-500 rounded-sm" />
                  <div className="bg-yellow-500 rounded-sm" />
                </div>
              </div>
              <span className="text-lg font-bold">{"متجر المكعبات"}</span>
            </div>
            <p className="text-sm text-muted-foreground text-pretty">
              {"مكعبات سرعة وألغاز متميزة لحلول من جميع المستويات."}
            </p>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">{"تسوق"}</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground">
                  {"جميع المنتجات"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"الأكثر مبيعاً"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"الوافدون الجدد"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"تخفيضات"}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">{"الدعم"}</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground">
                  {"مركز المساعدة"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"معلومات الشحن"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"الإرجاع"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"اتصل بنا"}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">{"الشركة"}</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="#" className="hover:text-foreground">
                  {"من نحن"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"المدونة"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"سياسة الخصوصية"}
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-foreground">
                  {"شروط الخدمة"}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>{"© 2025 متجر المكعبات. جميع الحقوق محفوظة."}</p>
        </div>
      </div>
    </footer>
  )
}

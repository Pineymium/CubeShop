import { Zap, Shield, Truck, HeartHandshake } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "سريع كالبرق",
    description: "مغناطيس متميز وآليات سلسة لحلول قياسية",
  },
  {
    icon: Shield,
    title: "صنع ليدوم",
    description: "مواد عالية الجودة تتحمل ملايين الدورات",
  },
  {
    icon: Truck,
    title: "شحن مجاني",
    description: "شحن مجاني في جميع أنحاء العالم على جميع الطلبات التي تزيد عن 50 دولار",
  },
  {
    icon: HeartHandshake,
    title: "إرجاع خلال 30 يوم",
    description: "غير راضٍ؟ أرجعه خلال 30 يوماً لاسترداد كامل المبلغ",
  },
]

export function Features() {
  return (
    <section id="features" className="bg-muted/50 py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-balance text-4xl font-bold tracking-tight md:text-5xl">
            {"لماذا تختار متجر المكعبات؟"}
          </h2>
          <p className="text-pretty text-lg text-muted-foreground">
            {"الخيار الموثوق لمحبي السرعة في جميع أنحاء العالم"}
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center"
              style={{
                animation: `slide-up 0.6s ease-out ${index * 0.1}s backwards`,
              }}
            >
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <feature.icon className="h-8 w-8" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">{feature.title}</h3>
              <p className="text-pretty text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-context"
import { CartDrawer } from "@/components/cart-drawer"
import { useState } from "react"

export function Header() {
  const { items } = useCart()
  const [cartOpen, setCartOpen] = useState(false)

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur-lg supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
              <div className="grid h-5 w-5 grid-cols-2 grid-rows-2 gap-[2px]">
                <div className="bg-red-500 rounded-sm" />
                <div className="bg-blue-500 rounded-sm" />
                <div className="bg-green-500 rounded-sm" />
                <div className="bg-yellow-500 rounded-sm" />
              </div>
            </div>
            <span className="text-xl font-bold tracking-tight">{"متجر المكعبات"}</span>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#products" className="text-sm font-medium transition-colors hover:text-primary">
              {"المنتجات"}
            </a>
            <a href="#features" className="text-sm font-medium transition-colors hover:text-primary">
              {"المميزات"}
            </a>
            <a href="#about" className="text-sm font-medium transition-colors hover:text-primary">
              {"من نحن"}
            </a>
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="relative" onClick={() => setCartOpen(true)}>
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                  {totalItems}
                </span>
              )}
            </Button>
          </div>
        </div>
      </header>
      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} />
    </>
  )
}

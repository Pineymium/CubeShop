"use client"

import { ProductCard } from "@/components/product-card"

const products = [
  {
    id: 1,
    name: "جان 12 ماجليف 3×3",
    price: 64.99,
    image: "/gan-12-maglev-3x3-speedcube-flagship-blue-modern-p.jpg",
    description: "تقنية ماجليف الرائدة مع طلاء UV ومغناطيس الزوايا ونظام شد قابل للتعديل",
    rating: 4.9,
    reviews: 892,
  },
  {
    id: 2,
    name: "مويو ويلونج WR M 2021",
    price: 49.99,
    image: "/moyu-weilong-wr-m-2021-speedcube-maglev-purple-pro.jpg",
    description: "نسخة الرقم القياسي العالمي مع نظام تعديل مزدوج وتقنية ماجليف الأساسية",
    rating: 4.8,
    reviews: 654,
  },
  {
    id: 3,
    name: "كيوي تورنادو V3 بايونير",
    price: 39.99,
    image: "/qiyi-tornado-v3-pioneer-speedcube-stickerless-brig.jpg",
    description: "إصدار بايونير مع تعديل حركة المركز وإعداد مصنع متميز",
    rating: 4.7,
    reviews: 523,
  },
  {
    id: 4,
    name: "جان 356 X V2",
    price: 54.99,
    image: "/gan-356-x-v2-speedcube-stickerless-adjustable-prod.jpg",
    description: "النموذج الرائد الكلاسيكي مع نواة IPG رقمية ومرونة قابلة للتعديل وقوة المغناطيس",
    rating: 4.8,
    reviews: 1247,
  },
  {
    id: 5,
    name: "مويو RS3 M 2020",
    price: 24.99,
    image: "/moyu-rs3-m-2020-speedcube-budget-magnetic-bright-s.jpg",
    description: "نموذج رائد اقتصادي مع مغناطيس قوي ودوران سلس، مثالي للمبتدئين",
    rating: 4.9,
    reviews: 2156,
  },
  {
    id: 6,
    name: "يوكسين ليتل ماجيك V2",
    price: 19.99,
    image: "/yuxin-little-magic-v2-speedcube-magnetic-colorful-.jpg",
    description: "إصدار V2 المحسّن مع تحديد مغناطيسي وقطع زوايا سلس كالزبدة",
    rating: 4.6,
    reviews: 1834,
  },
  {
    id: 7,
    name: "جان 11 M برو",
    price: 59.99,
    image: "/gan-11-m-pro-speedcube-uv-coated-professional-stic.jpg",
    description: "درجة احترافية مع طلاء UV ناعم وصواميل GES قابلة للتعديل ومغناطيس الزوايا الأساسية",
    rating: 4.9,
    reviews: 978,
  },
  {
    id: 8,
    name: "مويو ويلونج V9",
    price: 44.99,
    image: "/moyu-weilong-v9-speedcube-ball-core-uv-technology-.jpg",
    description: "أحدث إصدار V9 مع تقنية UV الكروية الثورية واستقرار محسّن",
    rating: 4.8,
    reviews: 445,
  },
  {
    id: 9,
    name: "إكس مان تورنادو V2 M",
    price: 34.99,
    image: "/x-man-tornado-v2-m-speedcube-ridged-flagship-dual-.jpg",
    description: "مكعب سرعة بتصميم مضلع وتعديل مزدوج وأداء معدل من المصنع",
    rating: 4.7,
    reviews: 712,
  },
]

export function ProductGrid() {
  return (
    <section id="products" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-balance text-4xl font-bold tracking-tight md:text-5xl">{"المجموعة المميزة"}</h2>
          <p className="text-pretty text-lg text-muted-foreground">{"اكتشف أشهر مكعبات السرعة والألغاز لدينا"}</p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          {products.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import { useEffect, useRef } from "react"
import Link from "next/link"

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = canvas.offsetWidth * 2
    canvas.height = canvas.offsetHeight * 2
    ctx.scale(2, 2)

    const particles: Array<{
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string
      rotation: number
      rotationSpeed: number
    }> = []

    const colors = ["#ef4444", "#3b82f6", "#22c55e", "#eab308", "#f97316", "#8b5cf6"]

    for (let i = 0; i < 20; i++) {
      particles.push({
        x: Math.random() * canvas.offsetWidth,
        y: Math.random() * canvas.offsetHeight,
        size: Math.random() * 15 + 10,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
      })
    }

    function animate() {
      if (!ctx || !canvas) return
      ctx.clearRect(0, 0, canvas.offsetWidth, canvas.offsetHeight)

      particles.forEach((particle) => {
        ctx.save()
        ctx.translate(particle.x, particle.y)
        ctx.rotate(particle.rotation)

        ctx.fillStyle = particle.color
        ctx.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size)

        ctx.restore()

        particle.x += particle.speedX
        particle.y += particle.speedY
        particle.rotation += particle.rotationSpeed

        if (particle.x < 0 || particle.x > canvas.offsetWidth) particle.speedX *= -1
        if (particle.y < 0 || particle.y > canvas.offsetHeight) particle.speedY *= -1
      })

      requestAnimationFrame(animate)
    }

    animate()
  }, [])

  return (
    <section className="relative overflow-hidden bg-background py-20 md:py-32">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full opacity-10" />

      <div className="container relative z-10 mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <div
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-muted px-4 py-1.5 text-sm font-medium"
            style={{ animation: "slide-up 0.6s ease-out" }}
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
            </span>
            {"مجموعة جديدة متاحة"}
          </div>

          <h1
            className="mb-6 text-balance text-5xl font-bold tracking-tight md:text-7xl"
            style={{ animation: "slide-up 0.6s ease-out 0.1s backwards" }}
          >
            {"احترف المكعب،"}
            <br />
            {"واحصل على المجموعة"}
          </h1>

          <p
            className="mb-10 text-pretty text-lg text-muted-foreground md:text-xl"
            style={{ animation: "slide-up 0.6s ease-out 0.2s backwards" }}
          >
            {"مكعبات سرعة متميزة للمبتدئين والمحترفين. دوران سلس، زوايا مثالية، جودة لا تُضاهى."}
          </p>

          <div
            className="flex flex-col gap-4 sm:flex-row sm:justify-center"
            style={{ animation: "slide-up 0.6s ease-out 0.3s backwards" }}
          >
            <Link href="/products">
              <Button size="lg" className="group text-base">
                {"تسوق المجموعة"}
                <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-base bg-transparent">
              {"الأكثر مبيعاً"}
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

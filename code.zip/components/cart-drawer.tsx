"use client"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { useCart } from "@/components/cart-context"
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react"
import Image from "next/image"

interface CartDrawerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CartDrawer({ open, onOpenChange }: CartDrawerProps) {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart()

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5" />
            {"سلة التسوق"}
          </SheetTitle>
          <SheetDescription>
            {items.length === 0 ? "سلتك فارغة" : `${items.length} ${items.length === 1 ? "منتج" : "منتجات"} في سلتك`}
          </SheetDescription>
        </SheetHeader>

        <div className="mt-8 flex flex-col gap-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingBag className="mb-4 h-16 w-16 text-muted-foreground/50" />
              <p className="text-lg font-medium">{"سلتك فارغة"}</p>
              <p className="text-sm text-muted-foreground">{"أضف بعض المكعبات للبدء!"}</p>
            </div>
          ) : (
            <>
              <div className="flex-1 space-y-4 overflow-auto pr-2">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4 rounded-lg border border-border p-4">
                    <div className="relative h-20 w-20 overflow-hidden rounded-md bg-muted">
                      <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                    </div>

                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-balance">{item.name}</h4>
                          <p className="text-sm text-muted-foreground">${item.price.toFixed(2)}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 cursor-pointer"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="mt-2 flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 cursor-pointer bg-transparent"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 cursor-pointer bg-transparent"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                        <span className="ml-auto font-semibold">${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-4 border-t border-border pt-4">
                <div className="flex items-center justify-between text-lg font-semibold">
                  <span>{"الإجمالي"}</span>
                  <span>${total.toFixed(2)}</span>
                </div>

                <Button className="w-full cursor-pointer" size="lg">
                  {"الدفع"}
                </Button>
                <Button variant="outline" className="w-full cursor-pointer bg-transparent" onClick={clearCart}>
                  {"إفراغ السلة"}
                </Button>
              </div>
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
